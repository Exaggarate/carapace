---
name: reserved-hook
description: reserved-hook
metadata: {"carapace":{"events":["command:new"]}}
---

# Hook