---
name: zip-hook
description: Zip hook
metadata: {"carapace":{"events":["command:new"]}}
---

# Zip Hook