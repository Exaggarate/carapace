---
name: tar-hook
description: tar-hook
metadata: {"carapace":{"events":["command:new"]}}
---

# Hook