---
name: evil-hook
description: evil-hook
metadata: {"carapace":{"events":["command:new"]}}
---

# Hook